﻿using UnityEngine;

public class DebugMenu : MonoBehaviour
{
    // ✨ แค่เติม [ContextMenu("ชื่อที่อยากให้โชว์")] ไว้บนหัวฟังก์ชันครับ

    [ContextMenu("🙋‍♂️ บังคับเสกลูกค้า")]
    public void ForceSpawnCustomer()
    {
        CustomerManager cm = FindObjectOfType<CustomerManager>();
        if (cm != null && cm.customerSlots.Length > 0)
        {
            int randomSlot = Random.Range(0, cm.customerSlots.Length);
            cm.SpawnCustomer(randomSlot);
            Debug.Log($"<color=cyan>[Debug]</color> บังคับเสกลูกค้าที่ช่อง {randomSlot}");
        }
    }

    [ContextMenu("🕵️‍♂️ บังคับเสกกลุ่มคนคุย")]
    public void ForceSpawnInvestigation()
    {
        InvestigationManager im = FindObjectOfType<InvestigationManager>();
        if (im != null)
        {
            StageConfig currentStage = GameManager.Instance.GetCurrentStage();
            im.SpawnGroup(currentStage);
            Debug.Log("<color=cyan>[Debug]</color> บังคับเสกกลุ่มสืบสวน");
        }
    }

    [ContextMenu("⏩ บังคับจบวันทันที")]
    public void ForceEndDay()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.StartEndOfDaySequence();
            Debug.Log("<color=cyan>[Debug]</color> บังคับข้ามเวลาไปจบวัน!");
        }
    }
}