﻿using UnityEngine;

public class InvestigateGroup : MonoBehaviour, IInvestigatable
{
    // ✨ ลบตัวแปร Canvas และ Image ออกไปแล้ว เพราะเราจะไปใช้ของ UIManager แทน

    [HideInInspector] public string clueDetail;
    [HideInInspector] public Transform assignedSpawnPoint;

    private float requiredListenTime;
    private float currentListenTime;
    private float lifeTimer;

    private bool isBeingListened = false;
    private bool isClueCollected = false;
    private InvestigationManager manager;

    public void Init(InvestigationManager mgr, string text, float duration)
    {
        manager = mgr;
        clueDetail = text;
        requiredListenTime = duration;
        lifeTimer = requiredListenTime + 10f;
    }

    private void Update()
    {
        if (lifeTimer > 0)
        {
            lifeTimer -= Time.deltaTime;
        }
        else if (!isClueCollected)
        {
            RemoveGroup();
            return;
        }

        // ✨ ถ้ากำลังถูกแอบฟังอยู่ ให้ส่งค่าเวลาไปอัปเดตหลอดที่หน้าจอหลัก
        if (isBeingListened && !isClueCollected)
        {
            UIManager.Instance.UpdateListeningBar(currentListenTime / requiredListenTime);
        }
    }

    public void OnListenStart()
    {
        if (!isClueCollected)
        {
            isBeingListened = true;
            // ✨ สั่งให้ UI บนหน้าจอหลักโชว์ขึ้นมา
            UIManager.Instance.ShowListeningBar(true);
        }
    }

    public void OnListening()
    {
        if (!isBeingListened || isClueCollected) return;

        currentListenTime += Time.deltaTime;

        if (currentListenTime >= requiredListenTime)
        {
            isClueCollected = true;
            isBeingListened = false;

            // ✨ ฟังจบแล้ว สั่งปิดหลอด
            UIManager.Instance.ShowListeningBar(false);
            manager.CollectClue(clueDetail);
            RemoveGroup();
        }
    }

    public void OnListenEnd()
    {
        if (isBeingListened)
        {
            isBeingListened = false;
            // ✨ ปล่อยเมาส์ปุ๊บ สั่งปิดหลอดทันที
            UIManager.Instance.ShowListeningBar(false);
        }
    }

    private void RemoveGroup()
    {
        // กันเหนียว: ถ้าคนเดินหนีไปตอนที่เรากำลังคลิกฟังอยู่ ก็ให้ปิดหลอดด้วย
        if (isBeingListened) UIManager.Instance.ShowListeningBar(false);

        manager.OnGroupLeft(this);
        Destroy(gameObject);
    }
}